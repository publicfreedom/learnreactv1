import logo from './logo.svg';
import './App.css';
import Greet from './components/Greet';
import Sidebar from './components/Sidebar';
import Sidebarright from './components/Sideright';
import Gprops from './components/Gprops';
import Classprops from './components/Classprops';

function App() {
  return (
       
     <div>   
      <Gprops  team="India" player = "Sachin Tedulkar" />
      <Gprops  team="Austerila" player = "Waston" />








      <Classprops technology="PHP"/>
      <Classprops technology="PHYTHON"/>
      <Classprops technology="DBTECH"/>
      <Classprops technology="XAMPPER"/>






      


      <Sidebar/>
      <Sidebarright/>

      
        
      </div>
      
  );
}




export default App;
