import React from 'react' 

function Greet(){
  return (
    <center><h1>Developer Bazaar Technologies</h1></center>
  );
}

export default Greet;
