import React, { Component} from 'react'

class Sidebarright extends Component {
    render(){
        return(
              <h3>Side Bar Left</h3>  
        );
    }
}

export default Sidebarright;