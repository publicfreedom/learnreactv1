import React from 'react'

function Gprops(props){
    return(
    <h3>Player Name {props.player} Team {props.team}</h3>
    );
}

export default Gprops;
