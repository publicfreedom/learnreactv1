import React, {Component} from 'react'

class Classprops extends Component{
     render(){
         return(
         <h4>Technology  { this.props.technology }</h4>
         );
     }
}

export default Classprops;