import React from 'react'

function Sidebar(){
    return(
        <h3>Side Bar Goes There</h3>
    );
}

export default Sidebar;
